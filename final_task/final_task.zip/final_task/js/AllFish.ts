namespace Aquarium{
    export class AllFish{
        x: number
        y: number
        dx: number 
        dy: number
        
        constructor(){

        }
        update(){};


    }
}