var Aquarium;
(function (Aquarium) {
    class AllObjects {
        constructor() {
        }
        update() { }
        ;
    }
    Aquarium.AllObjects = AllObjects;
})(Aquarium || (Aquarium = {}));
//# sourceMappingURL=AlleObjekte.js.map