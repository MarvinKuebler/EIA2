namespace Aquarium{
    export class AllObjects{
        size: number;
        x: number;
        y: number;
        dx: number; 
        dy: number
        
        constructor(){

        }
        update(){};
    }
}
