var Aquarium;
(function (Aquarium) {
    class AllFish {
        constructor() {
        }
        update() { }
        ;
    }
    Aquarium.AllFish = AllFish;
})(Aquarium || (Aquarium = {}));
//# sourceMappingURL=AllFish.js.map