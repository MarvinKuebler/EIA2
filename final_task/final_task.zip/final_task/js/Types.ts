

interface Scoreboard {
    [key: string]: string;
}

interface AquaHighScore {
    name: string;
    Highscore: number;
}

